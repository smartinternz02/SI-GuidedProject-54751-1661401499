Amphibians Kotlin Application - Solution Code 
==================================

Solution code for the fourth independent project for Android Basics in Kotlin. The application uses networking, JSON parsing, view models, and a custom API to display information in a list view with a RecyclerView. The user will be displayed with a list of amphibians where the user can then click on to see more information about them. 
<br>
<br>
<p align="center">
  <img src="https://user-images.githubusercontent.com/57158277/169911040-d459a42d-2e2a-4460-a9e9-a9a071481e03.png" width="250">
  <img src="https://user-images.githubusercontent.com/57158277/169911190-bbe0c0f5-78c2-452f-bcd7-0868e3388219.png" width="250">
</p>
If there is no stable internet connection when the application is opened, then the user will be presented with a connection error symbol on the screen. 
<br>
<br>
<p align="center">
  <img src="https://user-images.githubusercontent.com/57158277/169911440-d8076b17-fd32-4746-bac8-a418ed1c8131.png" width="250">
</p>


