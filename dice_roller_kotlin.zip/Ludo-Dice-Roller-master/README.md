# Ludo-Dice-Roller
Do you need a dice but you can't find it? Yes, this application is to change your dice. This application is just like your missing dice. This application can act as a virtual dice.
