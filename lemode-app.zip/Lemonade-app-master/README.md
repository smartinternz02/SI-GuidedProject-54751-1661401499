Project: Lemonade App 
=====================

This app still has bugs and needs fixing,
this is the first release
